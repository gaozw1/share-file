#install whl
pip3 install whl/*.whl
#install en_core_web_sm
pip3 install whl/*.gz
#link 
python3 -m spacy link en_core_web_sm en

#run example
#python3 chatbot.py